#!/usr/bin/env ruby

$pb_log_enabled = false
$pb_log_file = File.dirname(__FILE__) + "/other/log/pentbox_log_" + ENV['USER'] + ".log"

dir = File.dirname(__FILE__)
require dir + "/lib/pb_proced_lib.rb" # Common procedures and functions.

version = "1.8"
Signal.trap("INT") do
	puts ""
	puts "[*] EXITING ..."
	puts ""
	pb_write_log("exiting", "Core")
	exit
end
#####

pb_write_log("pentbox loaded", "Core")

srand(Time.now.to_i)
banner = rand(4)

puts ""
title " PenTBox #{version} "

# Thanks to Cowsay for the ASCII Art ;-)
case banner
	when 0
		# This banner is thanks to figlet.
		puts "    ____          _____ ____"
		puts "   |  _ \\ ___ _ _|_   _| __ )  _____  __"
		puts "   | |_) / _ \\ '_ \\| | |  _ \\ / _ \\ \\/ /"
		puts "   |  __/  __/ | | | | | |_) | (_) >  <"
		puts "   |_|   \\___|_| |_|_| |____/ \\___/_/\\_\\"
end

sleep(0.25)
module_exec = true
require "#{dir}/honeypot.rb"
Network_pb::Honeypot_pb.new()
