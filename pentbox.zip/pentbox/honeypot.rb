module Network_pb
class Honeypot_pb
def initialize()

require "socket"

puts ""
title "// Honeypot //"
puts ""
warning "You must run PenTBox with root privileges.\n"
puts ""

def honeyconfig(port, message, sound, log, logname) # Function to launch the Honeypot.
	begin
		tcpserver = TCPServer.new("", port)
		if tcpserver
			puts ""
			puts "  HONEYPOT ACTIVATED ON PORT #{port} (#{Time.now.to_s})"
			puts ""
			if log == "y" || log == "Y"
				# If log is enabled, writes Honeypot activation time.
				begin
					File.open(logname, "a") do |logf|
						logf.puts "#################### PenTBox Honeypot log"
						logf.puts ""
						logf.puts "  HONEYPOT ACTIVATED ON PORT #{port} (#{Time.now.to_s})"
						logf.puts ""
					end
				rescue Errno::ENOENT
					puts ""
					puts " Saving log error: No such file or directory."
					puts ""
				end
			end
			loop do
				socket = tcpserver.accept
				sleep(1) # It is to solve possible DoS Attacks.
				if socket
					Thread.new do
						remotePort, remoteIp = Socket.unpack_sockaddr_in(socket.getpeername) # Gets the remote port and ip.
						puts ""
						puts "  INTRUSION ATTEMPT DETECTED! from #{remoteIp}:#{remotePort} (#{Time.now.to_s})"
						puts " -----------------------------"
						reciv = socket.recv(1000).to_s
						puts reciv
						if sound == "y" || sound == "Y"
							# If sound is enabled, then beep 3 times.
							puts "\a\a\a"
						end
						if log == "y" || log == "Y"
							# If log is enabled, writes the intrusion.
							begin
								File.open(logname, "a") do |logf|
									logf.puts ""
									logf.puts "  INTRUSION ATTEMPT DETECTED! from #{remoteIp}:#{remotePort} (#{Time.now.to_s})"
									logf.puts " -----------------------------"
									logf.puts reciv
								end
							rescue Errno::ENOENT
								puts ""
								puts " Saving log error: No such file or directory."
								puts ""
							end
						end
						sleep(2) # This is a sticky honeypot.
						socket.write(message)
						socket.close
					end
				end
			end
		end
	rescue Errno::EACCES
		puts ""
		puts " Error: Honeypot requires root privileges."
		puts ""
	rescue Errno::EADDRINUSE
		puts ""
		puts " Error: Port in use."
		puts ""
	rescue
		puts ""
		puts " Unknown error."
		puts ""
	end
end

honeyconfig(50, "<HEAD>\n<TITLE>Lol u entered a honeypot!</TITLE>\n</HEAD>\n<H2>Lol u entered a honeypot!</H2>\n" + "<H3>Lol u entered a honeypot!</H3>\n", "N", "N", "")
honeyconfig(50, "<HEAD>\n<TITLE>Lol u entered a honeypot!</TITLE>\n</HEAD>\n<H2>Lol u entered a honeypot!</H2>\n" + "<H3>Lol u entered a honeypot!</H3>\n", "N", "N", "")
honeyconfig(50, "<HEAD>\n<TITLE>Lol u entered a honeypot!</TITLE>\n</HEAD>\n<H2>Lol u entered a honeypot!</H2>\n" + "<H3>Lol u entered a honeypot!</H3>\n", "N", "N", "")
end
end
end
